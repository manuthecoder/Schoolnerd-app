*: iqsdntnq
