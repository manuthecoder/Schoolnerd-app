<?php 
session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(!isset($_SESSION['valid'])) {
    header('Location: https://schoolnerd.ml/student/login?redirect_uri='.urlencode("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"));
}
if(isset($_POST['submit'])) {
     $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $sql = $dbh->prepare("SELECT * FROM classes WHERE id = :class");
        $sql->bindValue(':class', $_POST['joincode'], PDO::PARAM_STR);
        $sql->execute();
        $users1 = $sql->rowCount();
        $dbh = null;
        if($users1 == 1) {
             try {
              $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $sql = "INSERT INTO class_owned(name, login, cl) 
              VALUES(".json_encode('Student').", ".json_encode($_SESSION['id']).", ".json_encode($_POST['joincode']).")";
              $conn->exec($sql);
              header('Location: https://schoolnerd.ml/student/dash.php?class='.$_POST['joincode']);
            }
            catch(PDOException $e) { echo $sql . "<br>" . $e->getMessage(); }
        }
        else {
            header('Location: https://schoolnerd.ml/invite/?invalid');
        }
}

$joincode = $_GET['c'];


if(isset($_POST['agree'])) {
    
}
include('../student/include/nav.php');
?>
<div class="container" style="margin-top: 20vh">
<div class="container">
<div class="container">
    <h2>Join a class</h2>
    <form method="POST">
            <label>Join code</label>
            <input type="text" name="joincode">
        <button name="submit" class="btn green waves-effect waves-light">
            Submit
        </button>
    </form>
</div></div></div>
<?php 
if(isset($_GET['invalid'])) {
    ?>    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script>
        window.onload = function() {
            M.toast({html: 'Invalid class code...'});
        }
    </script>
    <?php
}
?>
