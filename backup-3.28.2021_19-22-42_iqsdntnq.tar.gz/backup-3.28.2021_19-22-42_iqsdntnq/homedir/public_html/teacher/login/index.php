<?php 
session_start();
if(isset($_SESSION['valid'])) {
    header('Location: https://schoolnerd.ml/teacher/?logged_in');
    exit;
}
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['submit'])) {
    $username1 = $_POST['username'];
    $pwd = hash('sha512', $_POST['password']);
    $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $sql = $dbh->prepare("SELECT * FROM users WHERE username = :uname AND password = :pwd");
    $sql->bindValue(':uname', $username1, PDO::PARAM_STR);
    $sql->bindValue(':pwd', $pwd, PDO::PARAM_STR);
    $sql->execute();
    $users = $sql->fetchAll();
    $users1 = $sql->rowCount();
    if($users1 == 1) {
        foreach ($users as $row) {
        // echo $row['username'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['valid'] = $row['username'];
        $_SESSION['id'] = $row['id'];
        header('Location: https://schoolnerd.ml/teacher/');
        exit;
        }
    }
    else {
        header('Location: https://schoolnerd.ml/teacher/login/?invalid');
    }
}
?>
<?php include('include/nav.php'); ?>
<div class="container" style="margin-top: 50px;">
    <div class="container">
        <div class="container">
            <div class="container">
                <form method="POST">
                    <img src="https://image.freepik.com/free-vector/login-concept-illustration_114360-739.jpg" width="200px" style="display:block;margin:auto" >
                    <h2 class="center">Login</h2>
                    <p class="center">To your ADMIN account!</p>
                    <div class="input-field">
                        <label>Username or Email</label>
                        <input type="text" name="username" autofocus autocomplete="off">
                    </div>
                    <div class="input-field">
                        <label>Password</label>
                        <input type="password" name="password" autocomplete="off">
                    </div>
                    <button name="submit" class="btn blue-grey darken-4 waves-effect waves-light">Submit</button>
                    <!--<p><i class="material-icons right">lightbulb_outline</i> Did you know that SchoolNerd was made *literally* for students to have fun in class? (Yeah, the name was chosen for a meme reason lol)</p>-->
                </form>
            </div>
        </div>
    </div>
</div>
<?php if(isset($_GET['invalid'])) {
?>
<script>
    window.onload = function() {
        document.getElementsByTagName('img')[0].src='https://sayingimages.com/wp-content/uploads/password-incorrect-password-memes.jpg';
        document.getElementsByTagName('img')[0].onmouseover = null;
        document.getElementsByTagName('img')[0].onmouseout = null;
        M.toast({html: 'Nope. Please try again or have your teacher reset it for you!'});
            history.pushState(null, null, '/student/login');
    }
</script>
<?php
}?>
<?php if(isset($_GET['success'])) {
?>
<script>
    window.onload = function() {
        M.toast({html: 'Successfully logged out!'});
            history.pushState(null, null, '/student/login/');
    }
</script>
<?php
}?>
<?php if(isset($_GET['yay'])) {
?>
<script>
    window.onload = function() {
        M.toast({html: 'Great Job! Successfully created account. Now, just log in to your acount.'});
            history.pushState(null, null, '/student/login/');
    }
</script>
<?php
}?>
<?php include('include/foot.php'); ?>