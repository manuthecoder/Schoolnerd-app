<!DOCTYPE html>
<?php include('./include/nav.php'); ?>
<html>
<body>

<form action="/action_page.php">
  <label for="fname">Email:</label>
  <input type="text" id="email" name="email"><br><br>
  <label for="lname">Reason:</label>
  <input type="text" id="reason" name="reason"><br><br>
  <input type="submit" value="Submit">
</form>

</body>
</html>

<div class="container">
<h2 class="center"> 
</div>
<?php include('./include/foot.php'); ?>
