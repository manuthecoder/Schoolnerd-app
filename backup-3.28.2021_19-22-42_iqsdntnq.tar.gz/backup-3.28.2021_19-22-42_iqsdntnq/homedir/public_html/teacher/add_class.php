<?php 
session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['class_submit'])) {
    $name = $_POST['class_name'];
    $class_wallpaper = $_POST['class_wallpaper'];
    $loginId = $_SESSION['id'];
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO classes(name, email, wallpaper, theme, header, description) 
      VALUES(".json_encode($name).", \"\", ".json_encode($class_wallpaper).", ".json_encode($_POST['class_color']).", ".json_encode($_POST['class_color']).", ".json_encode($_POST['desc']).")";
      $conn->exec($sql);
      $last_id = $conn->lastInsertId();
           try {
              $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $sql = "INSERT INTO class_owned(name, login, cl) 
              VALUES(\"Admin\" \"\", ".json_encode($_SESSION['id']).", ".json_encode($last_id).")";
              $conn->exec($sql);
              header('Location: https://schoolnerd.ml/student/dash.php?class='.$last_id."&new=1");
            }
            catch(PDOException $e) { echo $sql . "<br>" . $e->getMessage(); }
    } catch(PDOException $e) {
      echo $sql . "<br>" . $e->getMessage();
    }
    $conn = null;
}
include_once('./include/nav.php');
?>
<style>
.circle {
    width: 30px;
    display: inline-block;
    height: 30px;
    cursor:pointer;
    transition: all .2s;
    user-select: none;
}
.circle:hover {
    transform: scale(1.1);
}
.circle:active {
    transform: scale(.9);
}
</style>
<div class="container">
    <h3>Create a class</h3>
    <form method="POST">
        <div class="input-field">
            <label>Class Name</label>
            <input name="class_name" type="text" required class="validate">
        </div>
        <div class="input-field">
            <label>Class Wallpaper URL</label>
            <input name="class_wallpaper" type="url" required class="validate">
            <span onclick="$('#mainimg').click()">
                How do I find an Image URL?
            </span>            
            <img src="https://techboomers.com/wp-content/uploads/2018/11/right-click-save-as-2.png" width="20px" class="materialboxed" id="mainimg" style="opacity:0" onclick="this.style.opacity=1">
        </div>
        <div class="input-field">
            <label>Class theme color (RGBA/HEX/HSLA/HTML code)</label>
            <input type="text" name="class_color" id='color' class="validate">
            <span>
            <div class="circle deep-orange accent-3" onclick="color('#ff3d00')"></div>
            <div class="circle green" onclick="color('#4caf50')"></div>
            <div class="circle light-green" onclick="color('#8bc34a ')"></div>
            <div class="circle deep-purple" onclick="color('#673ab7')"></div>
            <div class="circle indigo darken-1" onclick="color('#3949ab')"></div>
            <div class="circle blue" onclick="color('#2196f3')"></div>
            <div class="circle cyan" onclick="color('#00bcd4')"></div>
            <div class="circle teal" onclick="color('#009688')"></div>
            <div class="circle amber" onclick="color('#ffc107')"></div>
            <div class="circle orange" onclick="color('#ff9800')"></div>
            <div class="circle orange darken-4" onclick="color('#e65100')"></div>
            <div class="circle deep-orange" onclick="color('#ff5722')"></div>
            <div class="circle brown" onclick="color('#8d6e63')"></div>
            <div class="circle pink" onclick="color('#e91e63')"></div>
            <div class="circle red" onclick="color('#f44336')"></div>
            <div class="circle light-blue" onclick="color('#03a9f4')"></div>
            <div class="circle light-blue darken-4" onclick="color('#01579b')"></div>
            <div class="circle lime" onclick="color('#cddc39')"></div>
            <div class="circle green accent-3" onclick="color('#00e676')"></div>
            <div class="circle light-green accent-3" onclick="color('#76ff03')"></div>
            <div class="circle grey darken-4" onclick="color('#212121')"></div>
            </span>
        </div>
        <div class="input-field">
            <label>Class Description</label>
            <textarea name="desc" class="materialize-textarea" style="min-height: 100px"></textarea>
        </div>
        <div>
            <button class="btn blue-grey darken-3" name="class_submit">Submit</button>
        </div>
    </form>
</div>
<script>
    $(document).ready(function() {
       $('.materialboxed').materialbox();
    });
    function color(data) {
        var x = document.getElementById('color');
        x.value = data;
        x.focus();
    }
</script>
<?php
include_once('./include/foot.php');
?>