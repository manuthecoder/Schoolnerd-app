<?php 
session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
?>
<?php include('include/nav.php'); ?>
<style>.header .card-content { padding-top: 50px !important; }#img {animation: check .8s forwards} @keyframes check {0% {transform: scale(0)} 60% {transform: scale(1.1)} 100% {transform: scale(1)} }</style>
<div class="container">
  <div class="card header" style="margin-top: 50px;">
      <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
          <span class="card-title white-text" style="font-size: 50px;">
              <?php echo $class_name; ?>
          </span><br>
      </div>
  </div>
  <div class="row">
      <div class="col s3">
          <a href="https://schoolnerd.ml/teacher/dash.php?class=<?php echo $_GET['class']; ?>">
              <div class="card waves-effect">
                  <div class="card-content">
                      <span class="card-title">
                         Back
                      </span>
                  </div>
                  </div>
          </a>
          <div class="card">
              <div class="card-content">
                  <span class="card-title">
                      Links
                  </span>
                  <p>
                      <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">Home</a><br>
                      <a href="https://schoolnerd.ml/student/add_post.php?class=<?php echo $_GET['class']; ?>">Create post</a>
                  </p>
              </div>
          </div>
      </div>
      <div class="col s9"> 
         <?php 
         $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $sql = $dbh->prepare("SELECT * FROM submission WHERE class = :class");
        $sql->bindValue(':class', $_GET['a'], PDO::PARAM_STR);
        $sql->execute();
        $users1 = $sql->rowCount();
        $users = $sql->fetchAll();
         foreach ($users as $row)
        {
            echo '<div class="card">
            <div class="card-content" style="padding-top: 10px;">
            <h4><b>'.$row['author'].'</b></h4>
            '.$row['content'].'
            </div></div>';
        }
        // echo "<br>". $users. "<br>";
        $dbh = null;
        ?>

  </div>
</div>
</div>
<?php include('include/foot.php'); ?>