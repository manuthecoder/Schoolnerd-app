<?php include('./include/nav.php'); ?>
<div class="container">
<h3 class="center">About the developers</h3>
<p>We are a group of people who love to code. This project was made for a competition, HackOR. We originally made this app, so that virtual learning could be fun, and full of <i>memes</i>, <i>interactivity</i>, and <i>learning</i>. We wanted to also make teachers give assignments to students <i>at ease</i>. This project is open source to all on github, and anyone can fork this project and create other remixes!</p>
  <ul class="collection">
    <li class="collection-item avatar">
      <img src="https://storage.googleapis.com/replit/images/1616812783435_97ee50282dd0dbd03112346d3dde3d47.webp" class="circle avatar">
      <span class="title"><b>Ishan Vannadil</b></span>
      <p>I'm a 7th grader who loves coding. My favorite languages are HTML and Python. <br>
         My hobbies include playing soccer, Minecraft, and Brawl Stars. I hope you enjoy our website!
      </p>
    </li>
    <li class="collection-item avatar">
      <img src="https://avatars.githubusercontent.com/u/77016441?s=460&u=7364273ea45ebd33bb2edecb8605d732850ec904&v=4" class="circle avatar">
      <span class="title"><b>Manusvath Gurudath</b></span>
      <p>I'm a passionate young developer who loves to code HTML, CSS, JS, PHP, and SQL.
      <br>
      Website: <a href="https://www.manuthecoder.ml/">www.manuthecoder.ml</a>
      </p>
    </li>
  </ul>
</div>
<?php include('./include/foot.php'); ?>
