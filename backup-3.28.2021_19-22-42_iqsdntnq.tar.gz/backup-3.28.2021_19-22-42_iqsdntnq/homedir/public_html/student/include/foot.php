 <?php if($actual_link !== 'https://schoolnerd.ml/student/add_post.php?class='.$class && $actual_link !== 'https://schoolnerd.ml/student' && $actual_link !== 'https://schoolnerd.ml/student/') {?>
 <?php if(!isset($_GET['hide_fab'])) {?>
<div class="fixed-action-btn">
  <a class="btn-floating btn-large blue-grey darken-3 waves-effect waves-light" href="add_post.php?class=<?php echo $class; ?>">
    <i class="large material-icons">add</i>
  </a>
</div>
 <?php } }?>
<script>
    const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
const currentTheme = localStorage.getItem('theme');

if (currentTheme) {
    document.documentElement.setAttribute('data-theme', currentTheme);
  
    if (currentTheme === 'dark') {
        toggleSwitch.checked = true;
    }
}

function switchTheme(e) {
    if (e.target.checked) {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
    }
    else {        document.documentElement.setAttribute('data-theme', 'light');
          localStorage.setItem('theme', 'light');
    }    
}

toggleSwitch.addEventListener('change', switchTheme, false);
</script>
 <!--<div style="width: 100%;background: rgba(0,0,0,0.1); padding: 10px;text-align:center">&copy;<?php echo date('Y'); ?> - SchoolNerd</div>-->
  <script src="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/js/materialize.min.js"></script>
  </body>
</html>