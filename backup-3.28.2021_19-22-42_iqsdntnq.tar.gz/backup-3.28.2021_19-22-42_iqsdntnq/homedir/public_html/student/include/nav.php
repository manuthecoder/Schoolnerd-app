<?php
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
// lol extremely :D strong password
?>
<?php 
$class = intval($_GET['class']);
$dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$sql = $dbh->prepare("SELECT * FROM classes WHERE id = :class");
$sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
$sql->execute();
$users = $sql->fetchAll();
foreach ($users as $row)
{
$class_name = $row['name'];
$class_desc = $row['description'];
$class_img = $row['wallpaper'];
}
$dbh = null;
$actual_link = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<!--
README: This is the dashboard.php file
Language: PHP
-->

<html class="notranslate" translate="no">
  <head>
    <title>SchoolNerd</title>
    <!--Materialize CSS CDN -->
    <link rel="shortcut icon" href="https://images-ext-2.discordapp.net/external/U5BlrRyRngqii-FjqMHJ5Y_-8mIM5FDmwxIxSTLAuKg/https/i.pinimg.com/originals/64/ac/eb/64aceba0537827b878c733b0ce477cf2.png?width=566&height=566">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/css/materialize.min.css"><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


    <style>
    :root {
      --primary-color: #302AE6;
      --secondary-color: #536390;
      --font-color: #424242;
      --bg-color: #fff;
      --heading-color: #292922;
    }
    
    [data-theme=dark] {
      --primary-color: #9A97F3;
      --secondary-color: #818cab;
      --font-color: #fff;
      --bg-color: #212121;
      --heading-color: #818cab;
    }
    input,textarea {color: var(--font-color);}
    body {background: var(--bg-color);color: var(--font-color); transition: .2s;}
    .card {color: var(--font-color) !important;background:rgba(255,255,255,.1);}
    nav {background: rgba(255,255,255,.2) !important;}
   nav * {color: var(--font-color) !important;}
.card .waves-ripple {transition-duration: .4s !important;} .card.waves-effect { width: 100%; } nav a {color:gray !important} .card {border-radius: 5px;} .header .card-content { padding-top: 200px; } a .card { color: #212121; }.btn-flat{background:transparent !important;} @media only screen and (max-width: 600px) { .header .card-content{ padding-top: 30px; } .header span { font-size: 30px !important; } .header p { font-size: 15px !important; } }
    </style> 
  </head>
  <body translate="no">
        <div class="theme-switch-wrapper" style="width: 0; height:0;overlow:hidden;display:none">
       <label class="theme-switch" for="checkbox">
    <input type="checkbox" id="checkbox" />
    <div class="slider round"></div>
  </label>
  </div>
  <nav>
  <ul>
  <li><a href="https://schoolnerd.ml/student" style="color: var(--font-color) !important;">SchoolNerd</a></li>
  </ul>
    <ul class="right">
  <li><a href="#" onclick="document.getElementById('checkbox').click()" style="color: var(--font-color) !important;">Dark mode</a></li>
  <li><a href="logout.php" style="color: var(--font-color) !important;">Logout</a></li>
  </ul>
  </nav>