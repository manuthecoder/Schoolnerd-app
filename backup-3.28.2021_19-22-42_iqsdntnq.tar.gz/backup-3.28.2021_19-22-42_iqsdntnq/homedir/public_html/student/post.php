  <?php include('include/nav.php'); ?>
  <style>.header .card-content { padding-top: 50px !important; }</style>
  <div class="container">
      <div class="card header" style="margin-top: 50px;">
          <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
              <span class="card-title white-text" style="font-size: 50px;">
                  <?php echo $class_name; ?>
              </span><br>
          </div>
      </div>
      <div class="row">
          <div class="col s3">
              <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">
                  <div class="card waves-effect">
                      <div class="card-content">
                          <span class="card-title">
                             Back
                          </span>
                      </div>
                      </div>
              </a>
                 <div class="card">
                      <div class="card-content">
                          <span class="card-title">
                              Links
                          </span>
                          <p>
                              <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">Home</a><br>
                              <a href="https://schoolnerd.ml/student/add_post.php?class=<?php echo $_GET['class']; ?>">Create post</a>
                          </p>
                      </div>
                  </div>
             <div class="card">
                  <div class="card-content">
                      <span class="card-title">
                         Assignments
                      </span>
                      <?php 
                        $class = $_GET['class'];
                        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        $sql = $dbh->prepare("SELECT * FROM assignments WHERE class = :class ORDER BY id DESC");
                        $sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
                        $sql->execute();
                        $users = $sql->fetchAll();
                        $rc = $sql->rowCount();
                        if($rc > 0) {
                            foreach ($users as $row) {
                                if($row['date_created'] == date('m/d/Y')) {
                                    echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
                                    <div class="card waves-effect" style="padding:0;box-shadow: none;border: 1px solid green">
                                    <div class="card-content" style="padding-top: 0 !Important"><br>
                                    <p><span class="badge new right"></span> '.$row['name'].' </p>
                                    <p>'.$row['points'].' points</p>
                                    </div>
                                    </div></a>';
                                }
                                else {
                                    echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
                                    <div class="card waves-effect" style="padding:0;box-shadow: none;border: 1px solid transparent">
                                    <div class="card-content" style="padding-top: 0 !Important">
                                    <p>'.$row['name'].'</p>
                                    <p>'.$row['points'].' points</p>
                                    </div>
                                    </div></a>';
                                }
                                }
                            }
                        else {
                            echo 'No Assignments!!!';
                        }
                        $dbh = null;
                      ?>
                  </div>
                </div>
          </div>
          <div class="col s9"> 
             <?php 
             $class = $_GET['class'];
            $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $sql = $dbh->prepare("SELECT * FROM threads WHERE id = :class");
            $sql->bindValue(':class', $_GET['p'], PDO::PARAM_STR);
            $sql->execute();
            $users = $sql->fetchAll();
            foreach ($users as $row)
            {
            echo '<div class="card">
            <div class="card-content">
            <h3>'.$row['title'].'</h3>
            <p>'.$row['content'].'</p>
            </div>
            </div>';
            }
            $dbh = null;
            ?>

      </div>
  </div>
  </div>
  <?php include('include/foot.php'); ?>