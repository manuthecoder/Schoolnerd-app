<?php session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['submit'])) {
    // echo $_POST['title2'];
     try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO threads(name, title, content, author, flagged, class) 
      VALUES(".json_encode($_POST['textt']).", ".json_encode($_POST['textt']).", ".json_encode($_POST['desc']).", ".json_encode($_SESSION['username']).",0,   ".json_encode($_GET['class']).")";
      $conn->exec($sql);
      header('Location: https://schoolnerd.ml/student/dash.php?class='.$_GET['class']);
    }
    catch(PDOException $e) { echo $sql . "<br>" . $e->getMessage(); }
}
include('include/nav.php');
?>
<style>.header .card-content { padding-top: 50px !important; }</style>
<div class="container">
  <div class="card header" style="margin-top: 50px;">
      <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
          <span class="card-title white-text" style="font-size: 50px;">
              <?php echo $class_name; ?>
          </span><br>
      </div>
  </div>
  <div class="row">
      <div class="col s3">
          <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">
              <div class="card waves-effect">
                  <div class="card-content">
                      <span class="card-title">
                         Back
                      </span>
                  </div>
                  </div>
          </a>
          <div class="card">
              <div class="card-content">
                  <span class="card-title">
                      Recent activity
                  </span>
                  <p>Coming Soon!</p>
              </div>
          </div>
           <?php include('nerds.php');?>
      </div>
      <div class="col s9"> 
        <form action="https://schoolnerd.ml/student/add_post.php?class=<?=$_GET['class']?>" method="POST">
            <div class="card">
                <div class="card-content">
                    <h6>Compose</h6>
                    <div class="input-field">
                        <label>Post title</label>
                        <input name="textt" class="materialize-textarea"type='text' autocomplete="off" required>
                    </div>
                    <div class="input-field">
                        <label>Content</label>
                        <textarea name="desc" class="materialize-textarea" autocomplete="off" required></textarea>
                    </div>
                    <a class="btn btn-flat waves-effect" href="https://schoolnerd.ml/student/">Cancel</a>
                    <button class="btn blue-grey waves-effect darken-3" name="submit">Post</button>
                </div>
            </div>
        </form>
  </div>
</div>
</div>
<?php include('include/foot.php'); ?>