<?php 
session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['submit'])) {
    $desc = $_POST['desc'];
     try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO submission(login_id, content, points, class, date, author) 
      VALUES(".json_encode($_SESSION['id']).", ".json_encode($desc).", \"\", ".json_encode($_GET['a']).", ".json_encode(date('d/m/Y')).", ".json_encode($_SESSION['username']).")";
      $conn->exec($sql);
      header('Location: https://schoolnerd.ml/student/dash.php?class='.$_GET['class']."&success");
    }
    catch(PDOException $e) { echo $sql . "<br>" . $e->getMessage(); }
}
?>
<?php include('include/nav.php'); ?>
<style>.header .card-content { padding-top: 50px !important; }#img {animation: check .8s forwards} @keyframes check {0% {transform: scale(0)} 60% {transform: scale(1.1)} 100% {transform: scale(1)} }</style>
<div class="container">
  <div class="card header" style="margin-top: 50px;">
      <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
          <span class="card-title white-text" style="font-size: 50px;">
              <?php echo $class_name; ?>
          </span><br>
      </div>
  </div>
  <div class="row">
      <div class="col s3">
          <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">
              <div class="card waves-effect">
                  <div class="card-content">
                      <span class="card-title">
                         Back
                      </span>
                  </div>
                  </div>
          </a>
          <div class="card">
              <div class="card-content">
                  <span class="card-title">
                      Links
                  </span>
                  <p>
                      <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">Home</a><br>
                      <a href="https://schoolnerd.ml/student/add_post.php?class=<?php echo $_GET['class']; ?>">Create post</a>
                  </p>
              </div>
          </div>
      </div>
      <div class="col s9"> 
         <?php 
         $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $sql = $dbh->prepare("SELECT * FROM submission WHERE class = :class AND login_id=:loginid");
        $sql->bindValue(':class', $_GET['a'], PDO::PARAM_STR);
        $sql->bindValue(':loginid', $_SESSION['id'], PDO::PARAM_STR);
        $sql->execute();
        $users1 = $sql->rowCount();
        $users = $sql->fetchAll();
         foreach ($users as $row)
        {
            $text = $row['content'];
        }
        // echo "<br>". $users. "<br>";
        // echo $users1;
        $dbh = null;
        if($users1 == 0) {
        $class = $_GET['class'];
        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $sql = $dbh->prepare("SELECT * FROM assignments WHERE id = :class");
        $sql->bindValue(':class', $_GET['a'], PDO::PARAM_STR);
        $sql->execute();
        $users = $sql->fetchAll();
        foreach ($users as $row)
        {
        echo '<div class="card">
        <div class="card-content" style="padding-top: 20px;">
        <p>Assignment Details</p>
        <h4 style="margin-top:0;"><b>'.$row['name'].'</b></h4>
        <p>Description: '.$row['description'].'</p>
        <p>'.$row['points'].' points</p>
        <p>Due by: '.$row['duedate'].'<br>Assignment ID: '.$row['id'].'</p><br><br>
        <button onclick="document.getElementById(\'form\').style.display=\'block\'" class="btn-large btn blue-grey waves-effect waves-light" style="width: 100%">Submit assignment</button>
        <form method="POST" style="display:none" id="form" action="https://schoolnerd.ml/student/assignment.php?a='.$_GET['a'].'&class='.$_GET['class'].'">
        <div class="input-field">
        <label>Submit assignment (Text entry/URL)</label>
        <textarea name="desc" class="materialize-textarea" style="min-height: 100px;"></textarea>
        </div>
        <button class="btn-laarge btn blue-grey waves-effect waves-light" name="submit">Submit assignment</button>
        </form>
        </div>
        </div>';
        }
        $dbh = null;
        }
        else {
            echo '<div class="card">
            <div class="card-content">
            <center>
            <img src="https://www.pngkit.com/png/full/776-7762350_download-transparent-check-mark-gif.png" width="200px" id="img">
            <h2><b>Assignment submitted!</b></h2>
            <p>Great Job! </p>
            </center>
            <br><br> <br><br><hr><h4>Submission details</h4><br>
            <p>'.htmlspecialchars($text).'</p>
            
            </div>
            </div>';
        }
        ?>

  </div>
</div>
</div>
<?php include('include/foot.php'); ?>