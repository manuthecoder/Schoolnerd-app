<?php 
session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
?>
<div class="card">
  <div class="card-content">
      <span class="card-title">
         Assignments
      </span>
      <?php 
       $class = $_GET['c'];
       echo $class;
        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $sql = $dbh->prepare("SELECT * FROM assignments WHERE class = :class ORDER BY id DESC");
        $sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
        $sql->execute();
        $users = $sql->fetchAll();
        $rc = $sql->rowCount();
        if($rc > 0) {
        foreach ($users as $row)
        {
        echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
        <div class="card waves-effect hoverable" style="padding:0">
        <div class="card-content" style="padding-top: 0 !Important">
        <h3>'.$row['title'].'</h3>
        <p>'.$row['content'].'</p>
        </div>
        </div></a>';
        }
        }
        else {
            echo 'No Assignments!!!';
        }
        $dbh = null;
      ?>
  </div>
</div>