<?php 
session_start();
if(isset($_SESSION['valid'])) {
    header('Location: https://schoolnerd.ml/student/?logged_in');
    exit;
}
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['submit'])) {
    $username1 = $_POST['username'];
    $pwd = hash('sha512', $_POST['password']);
    $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $sql = $dbh->prepare("SELECT * FROM users WHERE username = :uname AND password = :pwd");
    $sql->bindValue(':uname', $username1, PDO::PARAM_STR);
    $sql->bindValue(':pwd', $pwd, PDO::PARAM_STR);
    $sql->execute();
    $users = $sql->fetchAll();
    $users1 = $sql->rowCount();
    if($users1 == 1) {
        foreach ($users as $row) {
        // echo $row['username'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['id'] = $row['id'];
        $_SESSION['valid'] = $row['username'];
        header('Location: https://schoolnerd.ml/student/');
        exit;
        }
    }
    else {
        header('Location: https://schoolnerd.ml/student/login/?invalid');
    }
}
?>
<?php include('include/nav.php'); ?>
<div class="container" style="margin-top: 50px;">
    <div class="container">
        <div class="container">
            <div class="container">
                <form method="POST">
                    <img src="https://image.flaticon.com/icons/png/512/223/223198.png" width="200px" style="display:block;margin:auto" onmouseover="this.src='https://upload.wikimedia.org/wikipedia/en/9/9a/Trollface_non-free.png';M.toast({html: 'You discovered a secret!!!'})" onmouseout='this.src="https://image.flaticon.com/icons/png/512/223/223198.png"'>
                    <h2 class="center">Login</h2>
                    <p class="center">To your nerdy-nerd nerd account!</p>
                    <div class="input-field">
                        <label>Username or Email</label>
                        <input type="text" name="username" autofocus autocomplete="off">
                    </div>
                    <div class="input-field">
                        <label>Password</label>
                        <input type="password" name="password" autocomplete="off">
                    </div>
                    <button name="submit" class="btn blue-grey darken-4 waves-effect waves-light">Submit</button>
                    <!--<p><i class="material-icons right">lightbulb_outline</i> Did you know that SchoolNerd was made *literally* for students to have fun in class? (Yeah, the name was chosen for a meme reason lol)</p>-->
                </form>
            </div>
        </div>
    </div>
</div>
<?php if(isset($_GET['invalid'])) {
?>
<script>
    window.onload = function() {
        document.getElementsByTagName('img')[0].src='https://sayingimages.com/wp-content/uploads/password-incorrect-password-memes.jpg';
        document.getElementsByTagName('img')[0].onmouseover = null;
        document.getElementsByTagName('img')[0].onmouseout = null;
        M.toast({html: 'Nope. Please try again or have your teacher reset it for you!'});
            history.pushState(null, null, '/teacher/login');
    }
</script>
<?php
}?>
<?php if(isset($_GET['success'])) {
?>
<script>
    window.onload = function() {
        M.toast({html: 'Successfully logged out!'});
            history.pushState(null, null, '/teacher/login/');
    }
</script>
<?php
}?>
<?php if(isset($_GET['yay'])) {
?>
<script>
    window.onload = function() {
        M.toast({html: 'Great Job! Successfully created account. Now, just log in to your acount.'});
            history.pushState(null, null, '/teacher/login/');
    }
</script>
<?php
}?>
<?php include('include/foot.php'); ?>