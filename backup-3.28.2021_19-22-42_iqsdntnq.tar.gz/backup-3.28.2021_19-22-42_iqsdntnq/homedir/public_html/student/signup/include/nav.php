<?php
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
// lol extremely :D strong password
?>
<?php 
$class = intval($_GET['class']);
$dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$sql = $dbh->prepare("SELECT * FROM classes WHERE id = :class");
$sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
$sql->execute();
$users = $sql->fetchAll();
foreach ($users as $row)
{
$class_name = $row['name'];
$class_desc = $row['description'];
$class_img = $row['wallpaper'];
}
$dbh = null;
$actual_link = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<!--
README: This is the dashboard.php file
Language: PHP
-->

<html class="notranslate" translate="no">
  <head>
    <title>SchoolNerd</title>
    <!--Materialize CSS CDN -->
    <link rel="shortcut icon" href="https://images-ext-2.discordapp.net/external/U5BlrRyRngqii-FjqMHJ5Y_-8mIM5FDmwxIxSTLAuKg/https/i.pinimg.com/originals/64/ac/eb/64aceba0537827b878c733b0ce477cf2.png?width=566&height=566">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/css/materialize.min.css"><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


    <style>
.card .waves-ripple {transition-duration: .4s !important;} .card.waves-effect { width: 100%; } nav a {color:gray !important} .card {border-radius: 5px;} .header .card-content { padding-top: 200px; } a .card { color: #212121; }.btn-flat{background:transparent !important;} @media only screen and (max-width: 600px) { .header .card-content{ padding-top: 30px; } .header span { font-size: 30px !important; } .header p { font-size: 15px !important; } }
    </style> 
  </head>
  <body translate="no">
  <nav class="white">
  <ul>
  <li><a href="https://schoolnerd.ml/student">SchoolNerd</a></li>
  </ul>
    <ul class="right">
  <li><a href="https://schoolnerd.ml/student/login/">Login</a></li>
  </ul>
  </nav>