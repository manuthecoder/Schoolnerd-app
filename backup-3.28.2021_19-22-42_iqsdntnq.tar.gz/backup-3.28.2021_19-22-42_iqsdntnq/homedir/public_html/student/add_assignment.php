<?php session_start();
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['submit'])) {
    // echo $_POST['title2'];
     try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO assignments(name, points, duedate, date_created, description, class) 
      VALUES(".json_encode($_POST['title']).", ".json_encode($_POST['pts']).", ".json_encode($_POST['date']).",".json_encode(date('d/m/Y')).", ".json_encode($_POST['desc']).", ".json_encode($_GET['class']).")";
      $conn->exec($sql);
      header('Location: https://schoolnerd.ml/student/dash.php?class='.$_GET['class']);
    }
    catch(PDOException $e) { echo $sql . "<br>" . $e->getMessage(); }
}
include('include/nav.php');
?>
<style>.header .card-content { padding-top: 50px !important; }</style>
<div class="container">
  <div class="card header" style="margin-top: 50px;">
      <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
          <span class="card-title white-text" style="font-size: 50px;">
              <?php echo $class_name; ?>
          </span><br>
      </div>
  </div>
  <div class="row">
      <div class="col s3">
          <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">
              <div class="card waves-effect">
                  <div class="card-content">
                      <span class="card-title">
                         Back
                      </span>
                  </div>
                  </div>
          </a>
          <div class="card">
              <div class="card-content">
                  <span class="card-title">
                      Recent activity
                  </span>
                  <p>Coming Soon!</p>
              </div>
          </div>
          <div class="card">
                      <div class="card-content">
                          <span class="card-title">
                              Links
                          </span>
                          <p>
                              <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">Home</a><br>
                              <a href="https://schoolnerd.ml/student/add_post.php?class=<?php echo $_GET['class']; ?>">Create post</a>
                          </p>
                      </div>
                  </div>
             <div class="card">
                  <div class="card-content">
                      <span class="card-title">
                         Assignments
                      </span>
                      <?php 
                        $class = $_GET['class'];
                        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        $sql = $dbh->prepare("SELECT * FROM assignments WHERE class = :class ORDER BY id DESC");
                        $sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
                        $sql->execute();
                        $users = $sql->fetchAll();
                        $rc = $sql->rowCount();
                        if($rc > 0) {
                            foreach ($users as $row) {
                                if($row['date_created'] == date('m/d/Y')) {
                                    echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
                                    <div class="card waves-effect" style="padding:0;box-shadow: none;border: 1px solid green">
                                    <div class="card-content" style="padding-top: 0 !Important"><br>
                                    <p><span class="badge new right"></span> '.$row['name'].' </p>
                                    <p>'.$row['points'].' points</p>
                                    </div>
                                    </div></a>';
                                }
                                else {
                                    echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
                                    <div class="card waves-effect" style="padding:0;box-shadow: none;border: 1px solid transparent">
                                    <div class="card-content" style="padding-top: 0 !Important">
                                    <p>'.$row['name'].'</p>
                                    <p>'.$row['points'].' points</p>
                                    </div>
                                    </div></a>';
                                }
                                }
                            }
                        else {
                            echo 'No Assignments!!!';
                        }
                        $dbh = null;
                      ?>
                  </div>
                </div>
      </div>
      <div class="col s9"> 
        <form action="https://schoolnerd.ml/student/add_assignment.php?class=<?=$_GET['class']?>" method="POST">
            <div class="card">
                <div class="card-content">
                    <h6>Create new Assignment</h6>
                    <div class="input-field">
                        <label>Assignment name</label>
                        <input name="title" class="materialize-textarea" type='text' autocomplete="off" required>
                    </div>
                    <div class="input-field">
                        <label>Points worth</label>
                        <input name="pts" class="materialize-textarea" type='number' value='10' autocomplete="off" required>
                    </div>
                    <div class="input-field">
                        <label>Due date</label>
                        <input name="date" class="materialize-textarea datepicker" type='text' value='<?php echo date('m/d/Y'); ?>' autocomplete="off" required>
                    </div>
                    <div class="input-field">
                        <label>Assignment Description</label>
                        <textarea name="desc" class="materialize-textarea" autocomplete="off" required></textarea>
                    </div>
                    <a class="btn btn-flat waves-effect" href="https://schoolnerd.ml/student/">Cancel</a>
                    <button class="btn blue-grey waves-effect darken-3" name="submit">Post</button>
                </div>
            </div>
        </form>
  </div>
</div>
</div>
<script>
    
  $(document).ready(function(){
    $('.datepicker').datepicker({
      format: 'mm/dd/yyyy',
    });
  });
  
</script>
<?php include('include/foot.php'); ?>