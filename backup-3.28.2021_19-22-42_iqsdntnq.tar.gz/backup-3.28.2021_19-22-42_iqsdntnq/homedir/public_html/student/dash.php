<?php include('include/nav.php'); ?>
  <div class="container">
      <div class="card header" style="margin-top: 50px;">
          <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
              <span class="card-title white-text" style="font-size: 50px;">
                  <?php echo $class_name; ?>
              </span><br>
              <p class="white-text" style="font-size: 20px;"><?php echo $class_desc; ?><br> <?php echo "Class ID: ".$_GET['class']; ?></p>
          </div>
      </div>
      <div class="row">
          <div class="col s4">
              <div class="card">
                  <div class="card-content">
                      <span class="card-title">
                          Recent activity
                      </span>
                      <p>Coming Soon!</p>
                  </div>
              </div>
                  <div class="card">
                      <div class="card-content">
                          <span class="card-title">
                              Links
                          </span>
                          <p>
                              <a href="https://schoolnerd.ml/student/dash.php?class=<?php echo $_GET['class']; ?>">Home</a><br>
                              <a href="https://schoolnerd.ml/student/add_post.php?class=<?php echo $_GET['class']; ?>">Create post</a><br>
                              <!--<a href="https://schoolnerd.ml/student/add_assignment.php?class=<?php echo $_GET['class']; ?>">Create assignment</a>-->
                          </p>
                      </div>
                  </div>
               <div class="card">
                  <div class="card-content">
                      <span class="card-title">
                         Assignments
                      </span>
                      <?php 
                        $class = $_GET['class'];
                        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        $sql = $dbh->prepare("SELECT * FROM assignments WHERE class = :class ORDER BY id DESC");
                        $sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
                        $sql->execute();
                        $users = $sql->fetchAll();
                        $rc = $sql->rowCount();
                        if($rc > 0) {
                            foreach ($users as $row) {
                                if($row['date_created'] == date('m/d/Y')) {
                                    echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
                                    <div class="card waves-effect" style="padding:0;box-shadow: none;border: 1px solid green">
                                    <div class="card-content" style="padding-top: 0 !Important"><br>
                                    <p><span class="badge new right"></span> '.$row['name'].' </p>
                                    <p>'.$row['points'].' points</p>
                                    </div>
                                    </div></a>';
                                }
                                else {
                                    echo '<a href="assignment.php?a='.$row['id'].'&class='.$class.'">
                                    <div class="card waves-effect" style="padding:0;box-shadow: none;border: 1px solid transparent">
                                    <div class="card-content" style="padding-top: 10px !Important">
                                    <p>'.$row['name'].'</p>
                                    <p>'.$row['points'].' points</p>
                                    </div>
                                    </div></a>';
                                }
                                }
                            }
                        else {
                            echo 'No Assignments!!!';
                        }
                        $dbh = null;
                      ?>
                  </div>
                </div>
          </div>
          <div class="col s8"> 
             <?php 
            $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $sql = $dbh->prepare("SELECT * FROM threads WHERE class = :class ORDER BY id DESC");
            $sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
            $sql->execute();
            $users = $sql->fetchAll();
            foreach ($users as $row)
            {
            echo '<a href="post.php?p='.$row['id'].'&class='.$class.'"><div class="card waves-effect hoverable" style="padding:0">
            <div class="card-content" style="padding-top: 0 !Important">
            <h4><b>'.$row['title'].'</b></h4>
            <p>'.$row['content'].'</p>
            <p>Created by: '.$row['author'].'</p>
            </div>
            </div></a>';
            }
            $dbh = null;
            ?>

      </div>
</div>
<?php 
if(isset($_GET['success'])) {?>
<script>
window.onload = function() {
    M.toast({html: 'Successfuly turned in assignment!'})
}
</script>
<?php } ?>
 <?php include('include/foot.php');?>