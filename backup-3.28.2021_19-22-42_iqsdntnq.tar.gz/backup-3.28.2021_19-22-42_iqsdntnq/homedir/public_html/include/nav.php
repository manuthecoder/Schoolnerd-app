<!--
README: This is the index.php file
Language: PHP

GO TO ./student/dashboard.php to edit the STUDENT DASHBOARD
CHECK OUT https://schoolnerd.manuthecoder.repl.co/
-->

<html>
  <head>
    <title>SchoolNerd</title>
    <!--Materialize CSS CDN -->
    <link rel="shortcut icon" href="https://images-ext-2.discordapp.net/external/U5BlrRyRngqii-FjqMHJ5Y_-8mIM5FDmwxIxSTLAuKg/https/i.pinimg.com/originals/64/ac/eb/64aceba0537827b878c733b0ce477cf2.png?width=566&height=566">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/css/materialize.min.css">
    <meta name="title" content="SchoolNerd">
    <meta name="description" content="Welcome to SchoolNerd!  This is a website made for educational purposes, just like Google Classroom and Canvas. Click the buttons below to get started!">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://metatags.io/">
    <meta property="og:title" content="SchoolNerd">
    <meta property="og:description" content="Welcome to SchoolNerd!  This is a website made for educational purposes, just like Google Classroom and Canvas. Click the buttons below to get started!">
    <meta property="og:image" content="https://assets.materialup.com/uploads/daad5317-f377-406c-87f5-1360d6b90758/preview.jpg">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://metatags.io/">
    <meta property="twitter:title" content="SchoolNerd">
    <meta property="twitter:description" content="Welcome to SchoolNerd!  This is a website made for educational purposes, just like Google Classroom and Canvas. Click the buttons below to get started!">
    <meta property="twitter:image" content="https://assets.materialup.com/uploads/daad5317-f377-406c-87f5-1360d6b90758/preview.jpg">
    <style>
      nav a {color:gray !important}
    </style>
  </head>
  <body>
    <nav class="white">
      <ul>
        <li><a href="#" class="waves-effect">SchoolNerd</a></li>
      </ul>
      <ul class="right">
        <li><a href="https://schoolnerd.ml/about.php" class="waves-effect">About</a></li>
        <li><a href="https://schoolnerd.ml/student/login" class="waves-effect">Login</a></li>
      </ul>
    </nav>