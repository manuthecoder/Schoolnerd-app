    <footer class="page-footer blue-grey darken-3" style="background-color:#37474f !important">
      <div class="container">
        <div class="row">
          <div class="col l6 s12">
            <h5 class="white-text">SchoolNerd</h5>
            <p class="grey-text text-lighten-4">Made by 2 passionate young middle schoolers</p>
          </div>
          <div class="col l4 offset-l2 s12">
            <h5 class="white-text">Links</h5>
            <ul>
              <li><a class="grey-text text-lighten-3" href="https://schoolnerd.ml/student/signup/">Sign Up</a></li>
              <li><a class="grey-text text-lighten-3" href="https://schoolnerd.ml/student/login/">Login</a></li>
              <li><a class="grey-text text-lighten-3" href="https://schoolnerd.manuthecoder.repl.co/about.php">About Us</a></li>
              <li><a class="grey-text text-lighten-3" href="https://schoolnerd.ml/student">Dashboard</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-copyright">
        <div class="container">
          © <?php echo date('Y'); ?> Copyright
        </div>
      </div>
    </footer>
 <script>
    AOS.init();
  </script
    <script src="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/js/materialize.min.js"></script>
  </body>
</html>