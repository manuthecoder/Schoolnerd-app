<!DOCTYPE html>
<?php include('./include/nav.php'); ?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<div class="container center">
<div class="container center">
<div class="container center">
<h1>Contact</h1>
<p>Beep boop. Boop beep?</p>
<div class="container center">
<div class="g-recaptcha" data-sitekey="6LchwJEaAAAAAGgZIteb-EooTduvE50aTZ6Hr8Ea" data-callback='enableBtn'></div>
</div>
</div>
</div>
</div><br><br>
<script>
    function enableBtn() {
        window.location = "mailto:admin@schoolnerd.ml"
    }
</script>
<?php include('./include/foot.php'); ?>
