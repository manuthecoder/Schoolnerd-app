<?php include('./include/nav.php'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.8/typed.min.js"></script>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<style>
  .btn {
    margin: 3px;
  }
  .btn-flat {
    background: transparent !important
  }
  .typed-cursor {
    color: #1976d2 !important
  }
  hr{
    border: 0;
    height: 0;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
}
</style>
    <div class="container" style="margin-top: 15vh;">
      <div class="row">
        <div class="col s12 m7">
          <h2 data-aos="fade-up">Smart and <span class="blue-text text-darken-2" id="typed"></span> Classroom Management</h2>
          <p data-aos="fade-up" data-aos-delay="200">Welcome to SchoolNerd! This is a website made for educational purposes, just like Google Classroom and Canvas. Click the buttons below to get started!</p>
          <a data-aos="fade-up" data-aos-delay="400" href="https://schoolnerd.ml/student/signup" class="waves-effect waves-light btn purple darken-3 btn-large">Join Now!</a>
          <a data-aos="fade-up" data-aos-delay="400" href="https://schoolnerd.ml/request.php" class="waves-effect waves-light btn purple darken-3 btn-large">Become a Teacher</a>
        </div>
        <div class="col s5 hide-on-small-only" data-aos="fade-up" data-aos-delay="800">
          <img src="https://i.ibb.co/44C1g6d/kingdom-1069.png" width="100%">
        </div>
      </div>
    </div>
    <div class="container" style='margin-top: 10px;' >
      <div class="row">
        <div class="col s12">
          <h4 class="center"data-aos="fade-up">
            Features
          </h4>
        </div>
        <div class="col s12 m4" data-aos="fade-up">
          <div class="card medium">
            <div class="card-content">
            <center>
            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layout"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg></center><br>
              <span class="card-title">
                Easy to  navigate. SchoolNerd is a neat website used for many things, such as educational purposes accessible through classes.
              </span>
            </div>
          </div>
        </div>
        <div class="col s12 m4" data-aos="fade-up" data-aos-delay="200">
          <div class="card medium">
            <div class="card-content">
            <center><svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg></center>
              <span class="card-title">
                Better. SchoolNerd is a website just like Google Classroom, except better! For example, the classes are easier to interact with.
              </span>
            </div>
          </div>
        </div>
        <div class="col s12 m4" data-aos="fade-up" data-aos-delay="400">
          <div class="card medium">
            <div class="card-content">
            <center>
<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-sun"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg></center><br>
              <span class="card-title">
                Fun. SchoolNerd is fun for students to work with. Because of the interactive nature of the website, many students actually ENJOY learning!
              </span>
            </div>
          </div>
        </div>
      </div>
      <div class="section" data-aos="fade-up" data-aos-delay="100">
      <div class="row">
      <div class="col s2">
      <img src="https://pickaface.net/gallery/avatar/unr_random_180527_1151_2bcb7h9.png" width="100%" style="border-radius:999999999px;">
      </div>
      <div class="col s10">
      <p>My class has grown so much Because of this app. SchoolNerd has really made online virual learning fun and easy. It only takes 5 seconds to create a class. <br>- Chris Humphrey [Elementary School teacher at North Lake Camp at North Carolina, USA]</p>
      </div>
      </div>
      </div>
      <div class="section"> 
      <h3 class="center" data-aos="fade-up">FAQ</h3>
      <p data-aos="fade-up"><b>Q: How can students use SchoolNerd?</b><br>Just by clicking the "Join Now" button above. When you click this button, you will be redirected to a Signup page. After you signup, you will have the option to log in to your student account!</p>
      <hr data-aos="fade-up">
      <p data-aos="fade-up"><b>Q: How can teachers use SchoolNerd?</b><br>Just by clicking one simple button! Above, click the "Become a Teacher" button. Then, you can request to become a teacher. And with a good reason, BOOM!</p>
      <hr data-aos="fade-up">
      <p data-aos="fade-up"><b>Q: What is the point of SchoolNerd?</b><br>SchoolNerd is an improved version of google classroom, canvas, and other learning platforms. SchoolNerd is kid-friendly and is filled with memes and other surprises! 😉 Most importantly, we made this site for users to have FUN!</p>
      <hr data-aos="fade-up">
      <p data-aos="fade-up"><b>Q: Why don't I see any classes?!</b><br>Don't worry 😊. You just aren't enrolled in any classes yet. If you want to enroll in your classes, ask your teacher to tell you the class ID.</p>
      
      </div>
    </div>
  <script>
  new Typed('#typed',{
      strings : ['Easy','Sophisticated', 'Simple', 'Student-Friendly', 'Awesome'],
      typeSpeed : 40,
      delaySpeed : 90,
      backSpeed: 50,
      loop : true,
    });
  </script>
<?php include('./include/foot.php'); ?>