--- 
customlog: 
  - 
    format: combined
    target: /etc/apache2/logs/domlogs/schoolnerd.ml
  - 
    format: "\"%{%s}t %I .\\n%{%s}t %O .\""
    target: /etc/apache2/logs/domlogs/schoolnerd.ml-bytes_log
documentroot: /home/iqsdntnq/public_html
group: iqsdntnq
hascgi: 1
homedir: /home/iqsdntnq
ip: 78.31.66.142
owner: infinitz
phpopenbasedirprotect: 1
port: 80
scriptalias: 
  - 
    path: /home/iqsdntnq/public_html/cgi-bin
    url: /cgi-bin/
serveradmin: webmaster@schoolnerd.ml
serveralias: mail.schoolnerd.ml www.schoolnerd.ml
servername: schoolnerd.ml
usecanonicalname: 'Off'
user: iqsdntnq
