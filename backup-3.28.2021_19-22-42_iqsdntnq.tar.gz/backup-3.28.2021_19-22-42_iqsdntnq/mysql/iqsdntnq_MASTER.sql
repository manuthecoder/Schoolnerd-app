-- MySQL dump 10.19  Distrib 10.3.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: iqsdntnq_MASTER
-- ------------------------------------------------------
-- Server version	10.3.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `iqsdntnq_MASTER`
--


--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `points` text NOT NULL,
  `duedate` text NOT NULL,
  `date_created` text NOT NULL,
  `description` text NOT NULL,
  `class` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
INSERT INTO `assignments` (`id`, `name`, `points`, `duedate`, `date_created`, `description`, `class`) VALUES (1,'Assignment #1!','10','01/01/2022','03/27/2021','Create a web server and deploy your app!!!!',14),(2,'Assignment #2','100','03/27/2021','27/03/2021','CODE HTML, CSS, and JS',14),(3,'MANU IS OP','9999','09/15/2020','28/03/2021','Just Do It.',15),(4,'Student','10','04/07/2021','28/03/2021','Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah ',1),(5,'ree','10','03/28/2021','28/03/2021','reeeeeeeeeeeeeeeeeeeeeeeeeeeee',1),(6,'TEST COMPLETE THIS','100','03/28/2021','28/03/2021','TEST COMPLETE THIS',1),(7,'This is an assignment','100','03/27/2021','28/03/2021','Assignment Description!\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et lectus ac mi iaculis gravida. Proin odio lacus, ultricies eu dui ut, lobortis porta libero. Fusce a orci et neque porta hendrerit. In justo velit, blandit nec pretium faucibus, vestibulum id massa. Sed semper molestie urna, vitae laoreet nisi viverra sed. Quisque convallis diam nisi, quis tincidunt sem iaculis at. Maecenas nisl purus, viverra pulvinar ante in, fringilla efficitur leo. Proin vel vulputate sem, eu interdum elit. Pellentesque eget enim at leo iaculis placerat. Sed odio est, auctor sit amet dapibus at, interdum nec enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.',17),(8,'Assignment Name','10','03/28/2021','28/03/2021','Test description',18),(9,'Assignment Name','10','03/28/2021','28/03/2021','Test description',18);
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_owned`
--

DROP TABLE IF EXISTS `class_owned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_owned` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `login` text DEFAULT NULL,
  `cl` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_owned`
--

LOCK TABLES `class_owned` WRITE;
/*!40000 ALTER TABLE `class_owned` DISABLE KEYS */;
INSERT INTO `class_owned` (`id`, `name`, `login`, `cl`) VALUES (6,'Student','6',1),(7,'Student','2',2),(8,'Student','2',3),(9,'Student','2',4),(10,'Student','2',5),(11,'Student','2',6),(13,'Student','1',2),(14,'Student','1',3),(15,'Student','1',4),(16,'Student','1',5),(17,'Student','1',6),(23,'Admin','2',14),(25,'Admin','8',15),(26,'15','8',15),(27,'Student','8',15),(28,'1','9',1),(29,'69','9',69),(30,'1','9',1),(31,'Student','9',1),(33,'Student','1',1),(34,'Admin','11',16),(35,'Admin','12',17),(36,'Admin','13',18);
/*!40000 ALTER TABLE `class_owned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `wallpaper` text NOT NULL,
  `theme` text NOT NULL,
  `header` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` (`id`, `name`, `email`, `wallpaper`, `theme`, `header`, `description`) VALUES (1,'SchoolNerd','hello@smartlist.ga','https://steamuserimages-a.akamaihd.net/ugc/1488956313093009858/D24763C742A4612409D14D96412571E2694DD8E4/','dark','#212121','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur semper urna ac consequat imperdiet. '),(2,'Math','','https://i.pinimg.com/originals/eb/a3/9e/eba39ebd3f4131e65390a922327e1323.jpg','','','Test'),(3,'Science','','https://wallpapercave.com/wp/wp2035648.jpg','','','EXAMPLE'),(4,'ELA','','https://www.britishcouncil.org/sites/default/files/how_can_film_help_teach_learn_english.jpg','','','EXAMPLE'),(5,'History','','https://wallpapercave.com/wp/wp2244206.jpg','','','EXAMPLE'),(6,'PE','','https://wallpaperaccess.com/full/4268425.jpg','','','EXAMPLE'),(13,'Class name','','https://storage.googleapis.com/replit/images/1616812783435_97ee50282dd0dbd03112346d3dde3d47.webp','#f44336','#f44336','Description\r\n'),(14,'HACKER TIME','','https://wallpapercave.com/wp/wp3198575.jpg','#212121','#212121','Hacker time is a Default class in SchoolNerd! Hack and code whatever you want!'),(15,'adminee','','https://wallpaperaccess.com/full/16668.jpg','#76ff03','#76ff03','admineee'),(16,'Class Name','','https://wallpaperaccess.com/8k-hacker','#3949ab','#3949ab','Welcome to this demo class!!!'),(17,'This is a demo class','','https://wallpaperaccess.com/full/3288227.jpg','#673ab7','#673ab7','This is a demo class!'),(18,'Class','','https://wallpaperaccess.com/full/3288227.jpg','#e65100','#e65100','Class name');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission`
--

DROP TABLE IF EXISTS `submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` text NOT NULL,
  `content` text NOT NULL,
  `points` text NOT NULL,
  `class` text DEFAULT NULL,
  `date` text NOT NULL,
  `author` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission`
--

LOCK TABLES `submission` WRITE;
/*!40000 ALTER TABLE `submission` DISABLE KEYS */;
INSERT INTO `submission` (`id`, `login_id`, `content`, `points`, `class`, `date`, `author`) VALUES (1,'1','classclassclassclassclass','','5','28/03/2021','Admin'),(5,'1','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et lectus ac mi iaculis gravida. Proin odio lacus, ultricies eu dui ut, lobortis porta libero. Fusce a orci et neque porta hendrerit. In justo velit, blandit nec pretium faucibus, vestibulum id massa. Sed semper molestie urna, vitae laoreet nisi viverra sed. Quisque convallis diam nisi, quis tincidunt sem iaculis at. Maecenas nisl purus, viverra pulvinar ante in, fringilla efficitur leo. Proin vel vulputate sem, eu interdum elit. Pellentesque eget enim at leo iaculis placerat. Sed odio est, auctor sit amet dapibus at, interdum nec enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.','','6','28/03/2021','Admin'),(6,'9','stop using caps. I refuse to do it. HAHA NOOB','','6','28/03/2021','teacher'),(7,'12','HACKOR DEMO SLIDES (Opening ceremony)\r\n\r\nhttps://docs.google.com/presentation/d/10Q0fmDZMhaanyJYvQiegBvWsPdPvgeq7t1GT15qmvMU/edit','','7','28/03/2021','demo'),(8,'13','https://wallpaperaccess.com/full/3288227.jpg','','9','28/03/2021','demo1');
/*!40000 ALTER TABLE `submission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threads` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `author` text NOT NULL,
  `flagged` text NOT NULL,
  `class` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `threads`
--

LOCK TABLES `threads` WRITE;
/*!40000 ALTER TABLE `threads` DISABLE KEYS */;
INSERT INTO `threads` (`id`, `name`, `title`, `content`, `author`, `flagged`, `class`) VALUES (1,'Welcome to SchoolNerd!','Welcome to SchoolNerd!','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur semper urna ac consequat imperdiet. Phasellus fermentum auctor mauris, non elementum mi bibendum quis. Mauris consectetur rhoncus tempus. Quisque viverra augue in dolor vulputate, at finibus dui sagittis. Mauris auctor nisl mauris. Donec in lorem et eros varius convallis. Duis vel ornare turpis. Maecenas elit tellus, fermentum sed sapien at, interdum congue turpis. Sed pellentesque scelerisque nisl a vestibulum. Sed lobortis elit vitae magna commodo, ut vulputate velit venenatis. Proin ut purus dignissim, bibendum augue vel, vulputate neque. Sed accumsan vulputate dui quis pulvinar. Sed sodales massa sit amet arcu fermentum faucibus.</p> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur semper urna ac consequat imperdiet. Phasellus fermentum auctor mauris, non elementum mi bibendum quis. Mauris consectetur rhoncus tempus. Quisque viverra augue in dolor vulputate, at finibus dui sagittis. Mauris auctor nisl mauris. Donec in lorem et eros varius convallis. Duis vel ornare turpis. Maecenas elit tellus, fermentum sed sapien at, interdum congue turpis. Sed pellentesque scelerisque nisl a vestibulum. Sed lobortis elit vitae magna commodo, ut vulputate velit venenatis. Proin ut purus dignissim, bibendum augue vel, vulputate neque. Sed accumsan vulputate dui quis pulvinar. Sed sodales massa sit amet arcu fermentum faucibus.</p>','Admin','0','1'),(2,'Science Assignment Due!','Science Assignment Due!','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur semper urna ac consequat imperdiet. Phasellus fermentum auctor mauris, non elementum mi bibendum quis. Mauris consectetur rhoncus tempus. Quisque viverra augue in dolor vulputate, at finibus dui sagittis. Mauris auctor nisl mauris. Donec in lorem et eros varius convallis. Duis vel ornare turpis. Maecenas elit tellus, fermentum sed sapien at, interdum congue turpis. Sed pellentesque scelerisque nisl a vestibulum. Sed lobortis elit vitae magna commodo, ut vulputate velit venenatis. Proin ut purus dignissim, bibendum augue vel, vulputate neque. Sed accumsan vulputate dui quis pulvinar. Sed sodales massa sit amet arcu fermentum faucibus.</p> ','Admin','0','1'),(3,'Math Test coming up soon','Math test soon','Test','','0','2'),(5,'Hi there!','Hi there!','Welcome to hacker time\r\nThis is a fun place to show off your hacking skills. \r\nHave fun!!!!!','test','0','14'),(6,'Post title','Post title','ree\r\ne\r\ne\r\n\r\ne\r\ne\r\ne','test','0','3'),(7,'Test','Test','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu faucibus massa. Phasellus dignissim, urna et vehicula accumsan, diam sapien imperdiet neque, at aliquam nisi justo non justo. Nunc ipsum dolor, tincidunt quis risus cursus, accumsan euismod massa. Pellentesque eget lorem ac metus hendrerit vehicula et vel purus. Quisque porta cursus felis, pretium aliquet sapien gravida sit amet. In in metus porta, facilisis neque nec, auctor erat. Sed tempus fermentum eros, nec malesuada dui dictum ut.','test','0','14'),(8,'ree','ree','reee','admine','0','15'),(9,'Test','Test','Test','Admin','0','1'),(10,'This is a demo post','This is a demo post','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et lectus ac mi iaculis gravida. Proin odio lacus, ultricies eu dui ut, lobortis porta libero. Fusce a orci et neque porta hendrerit. In justo velit, blandit nec pretium faucibus, vestibulum id massa. Sed semper molestie urna, vitae laoreet nisi viverra sed. Quisque convallis diam nisi, quis tincidunt sem iaculis at. Maecenas nisl purus, viverra pulvinar ante in, fringilla efficitur leo. Proin vel vulputate sem, eu interdum elit. Pellentesque eget enim at leo iaculis placerat. Sed odio est, auctor sit amet dapibus at, interdum nec enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.','demo','0','17'),(11,'Post title','Post title','Content','demo1','0','18');
/*!40000 ALTER TABLE `threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `ip` text NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`, `ip`, `date`) VALUES (1,'Admin','036b4682039f7e34cd57a8df4b38695715a6d726f17719f87afcd070b532ae2983f360f7133051571e21044d582ed7e7d8ba4e48c3f8a0fc7ccf852206431ddd','','1/2/3'),(2,'test','ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff','',''),(3,'test113724','y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk','','Sat/Mar/2021 04:0:th'),(6,'Ishan','6b6beeca1226098bcc7367e4fc61511525d61bd6efa280b760e4721e141736baa70e524d50e99721e1d999e4bc8965729eff95e01d75c855b849dfe762e8c566','','Sat/Mar/2021 17:0:th'),(7,'SorryNoob','63b825b802f9c7d9c3257e52291ffaba4a5e0eb86d3f8fe76f189dd1b8fedcf69548af7cc23ee39502dfae3f56333f47dcfe597bc694eaa1dab680574e63a178','','Sat/Mar/2021 18:0:th'),(8,'admine','c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec','','Sun/Mar/2021 01:0:th'),(9,'teacher','f657a11b6f1f73e374f13a5e950d4c2d36d82618716fef8a06e474f084795a27a2ba4f8b664e4f44736387a61ad92e92f977db9a678ccc0103995462e6ef658c','','Sun/Mar/2021 02:0:th'),(10,'testt','3f23b4f6aa157596cc0f859e3d21b90d12be06d7679a99bf32d6fdb5e5c58518168f60c440c5531f154b16d9d1f31e2a59fa9c438cbef81b82efc4077860c8ed','','Sun/Mar/2021 02:0:th'),(11,'iAmATeacher','4805af8fa90847842aaa77ef3dda1a9d05c2615fbf13fd1984c8165c9e82f7f6368be292ccc835eacf29c3fadb073281531f56ab09dd73d2da67308af31c7952','','Sun/Mar/2021 04:0:th'),(12,'demo','26c669cd0814ac40e5328752b21c4aa6450d16295e4eec30356a06a911c23983aaebe12d5da38eeebfc1b213be650498df8419194d5a26c7e0a50af156853c79','','Sun/Mar/2021 04:0:th'),(13,'demo1','7da0b81ac186d7136e307ef87f397f8c76bdc7d2a3aa4efc6647bf9ad787dd35629ccc06920f1f2d8e03f9bfb5fc814d95f4f76d3b50fd367700c971d70136eb','','Sun/Mar/2021 04:0:th');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'iqsdntnq_MASTER'
--

--
-- Dumping routines for database 'iqsdntnq_MASTER'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-28 19:22:42
