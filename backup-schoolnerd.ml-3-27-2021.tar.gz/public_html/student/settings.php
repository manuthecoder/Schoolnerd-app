<?php include('./include/nav.php'); ?>
<?php include('./include/foot.php'); ?>