<div class="card">
  <div class="card-content">
      <span class="card-title">
          Top NERDS
      </span>
      <p>Coming Soon!</p>
      <p>Coming Soon!</p>
      <p>Coming Soon!</p>
      <p>Coming Soon!</p>
      <p>Coming Soon!</p>
      <p>Coming Soon!</p>
  </div>
</div>