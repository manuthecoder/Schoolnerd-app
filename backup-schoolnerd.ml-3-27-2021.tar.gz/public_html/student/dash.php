<?php include('include/nav.php'); ?>
  <div class="container">
      <div class="card header" style="margin-top: 50px;">
          <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
              <span class="card-title white-text" style="font-size: 50px;">
                  <?php echo $class_name; ?>
              </span><br>
              <p class="white-text" style="font-size: 20px;"><?php echo $class_desc; ?></p>
          </div>
      </div>
      <div class="row">
          <div class="col s4">
              <div class="card">
                  <div class="card-content">
                      <span class="card-title">
                          Recent activity
                      </span>
                      <p>Coming Soon!</p>
                  </div>
              </div>
               <?php include('nerds.php');?>
          </div>
          <div class="col s8"> 
             <?php 
             $class = $_GET['class'];
            $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $sql = $dbh->prepare("SELECT * FROM threads WHERE class = :class");
            $sql->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
            $sql->execute();
            $users = $sql->fetchAll();
            foreach ($users as $row)
            {
            echo '<a href="post.php?p='.$row['id'].'&class='.$class.'"><div class="card waves-effect hoverable">
            <div class="card-content">
            <h3>'.$row['title'].'</h3>
            <p>'.$row['content'].'</p>
            </div>
            </div></a>';
            }
            $dbh = null;
            ?>

      </div>
</div>
 <?php include('include/foot.php');?>