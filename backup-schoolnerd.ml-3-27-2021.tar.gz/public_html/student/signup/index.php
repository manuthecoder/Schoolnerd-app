<?php 
// session_start();
// if(isset($_SESSION['valid'])) {
//     header('Location: https://schoolnerd.ml/student/?logged_in');
//     exit;
// }
$servername = 'localhost';
$dbname =  'iqsdntnq_MASTER';
$username = 'iqsdntnq';
$password = 'y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk';
if(isset($_POST['submit'])) {
    $username1 = $_POST['username'];
    $pwd = hash('sha512', $_POST['password']);
    $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $sql = $dbh->prepare("SELECT * FROM users WHERE username = :uname");
    $sql->bindValue(':uname', $username1, PDO::PARAM_STR);
    $sql->execute();
    $users1 = $sql->rowCount();
    if($users1 == 0) {
      try {
          $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          $sql = "INSERT INTO users(username, password, ip, date) 
          VALUES(".json_encode($username1).",".json_encode($pwd).",\"\", \"".date('D/M/Y H:I:S')."\")";
          $conn->exec($sql);
          header('Location: https://schoolnerd.ml/student/login/?yay');
        } catch(PDOException $e) {
          echo $sql . "<br>" . $e->getMessage();
        }
    }
    else {
        header('Location: https://schoolnerd.ml/student/signup/?taken');
    }
}
?>
<?php include('include/nav.php'); ?>
<div class="container" style="margin-top: 50px;">
    <div class="container">
        <div class="container">
            <div class="container">
                <form method="POST">
                    <center><img src="https://lh3.googleusercontent.com/proxy/xAA_PgRzYBR8cfyz3zqHOwFhVuC8Hy_-Pv_TLnbFmcuNd2Phe58MjMuAi9EZwhLbeAkSmux9edHU3L1XEHR64tQ9mQ" width="200px"></center>
                    <h2 class="center">Sign Up</h2>
                    <p class="center">Get access to your class, and of course, memes!</p>
                    <div class="input-field">
                        <label>Username or Email</label>
                        <input type="text" name="username" autofocus>
                        <span>Please give us a <b>valid</b> email in case you forget your password!</span>
                    </div>
                    <div class="input-field">
                        <label>Password</label>
                        <input type="text" name="password">
                        <span>Make sure to have a <b>strong</b> password!</span>
                    </div>
                    <button name="submit" class="btn blue-grey darken-4 waves-effect waves-light">Submit</button>
                    <!--<p><i class="material-icons right">lightbulb_outline</i> Did you know that SchoolNerd was made *literally* for students to have fun in class? (Yeah, the name was chosen for a meme reason lol)</p>-->
                </form>
            </div>
        </div>
    </div>
</div>
<?php if(isset($_GET['taken'])) {
?>
<script>
    window.onload = function() {
        M.toast({html: 'Oops. Username already taken?!?! Might be your evil twin sister ;)'});
            history.pushState(null, null, '/student/signup/');
    }
</script>
<?php
}?>
<?php include('include/foot.php'); ?>