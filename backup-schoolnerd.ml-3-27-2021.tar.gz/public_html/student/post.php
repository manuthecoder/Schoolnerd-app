  <?php include('include/nav.php'); ?>
  <style>.header .card-content { padding-top: 50px !important; }</style>
  <div class="container">
      <div class="card header" style="margin-top: 50px;">
          <div class="card-content" style="background: url('<?php echo $class_img; ?>');background-size: cover;background-repeat: no-repeat">
              <span class="card-title white-text" style="font-size: 50px;">
                  <?php echo $class_name; ?>
              </span><br>
          </div>
      </div>
      <div class="row">
          <div class="col s3">
              <a href="https://schoolnerd.ml/student/?class=<?php echo $_GET['class']; ?>">
                  <div class="card waves-effect">
                      <div class="card-content">
                          <span class="card-title">
                             Back
                          </span>
                      </div>
                      </div>
              </a>
              <div class="card">
                  <div class="card-content">
                      <span class="card-title">
                          Recent activity
                      </span>
                      <p>Coming Soon!</p>
                  </div>
              </div>
               <?php include('nerds.php');?>
          </div>
          <div class="col s9"> 
             <?php 
             $class = $_GET['class'];
            $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $sql = $dbh->prepare("SELECT * FROM threads WHERE id = :class");
            $sql->bindValue(':class', $_GET['p'], PDO::PARAM_STR);
            $sql->execute();
            $users = $sql->fetchAll();
            foreach ($users as $row)
            {
            echo '<div class="card">
            <div class="card-content">
            <h3>'.$row['title'].'</h3>
            <p>'.$row['content'].'</p>
            </div>
            </div>';
            }
            $dbh = null;
            ?>

      </div>
  </div>
  </div>
  <?php include('include/foot.php'); ?>