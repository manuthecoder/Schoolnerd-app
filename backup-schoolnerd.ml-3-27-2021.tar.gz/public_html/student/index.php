<?php 
session_start();
if(!isset($_SESSION['valid'])) {
    header('Location: https://schoolnerd.ml/student/login');
    exit;
}
include('include/nav.php'); ?>
  <div class="container">
      <h3>All Classes</h3>
     <div class="row">
         <?php 
        $login_id = $_SESSION['id'];
        // echo $login_id;
        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $sql = $dbh->prepare("SELECT * FROM class_owned WHERE login = :login_id AND name='Student'");
        $sql->bindValue(':login_id', $login_id, PDO::PARAM_STR);
        $sql->execute();
        $users = $sql->fetchAll();
        foreach ($users as $row) {
            $dbh_1 = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $sql_1 = $dbh_1->prepare("SELECT * FROM classes WHERE id=".$row['cl']);
            $sql_1->bindValue(':class', $_GET['class'], PDO::PARAM_STR);
            $sql_1->execute();
            $users_1 = $sql_1->fetchAll();
            foreach ($users_1 as $row_1) {
            echo '<div class="col s4">
                        <a href="dash.php?class='.$row_1['id'].'">
                          <div class="card waves-effect waves-light">
                            <div class="card-image">
                              <img src="'.$row_1['wallpaper'].'" style="width: 100%;height: 200px;object-fit:cover">
                              <span class="card-title">'.$row_1['name'].'</span>
                            </div>
                          </div>
                        </a>
                    </div>';
        }
        $dbh_1 = null;
        
        
        
        }
        $dbh = null;
        ?>
        
     </div>
</div>
<?php if(isset($_GET['logged_in'])) {
?>
<script>
    window.onload = function() {
        M.toast({html: 'You\'re already logged in <img src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/twitter/73/winking-face_1f609.png" width="20px" style="vertical-align:middle;margin-left: 10px">'})
        history.pushState(null, null, '/student/');
    }
</script>
<?php
}?>
 <?php include('include/foot.php');?>