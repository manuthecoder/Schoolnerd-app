<?php 
session_start();
if(!isset($_SESSION['valid'])) {
    header('Location: https://schoolnerd.ml/login?redirect_uri='.urlencode("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"));
}
$joincode = $_GET['c'];


if(isset($_POST['agree'])) {
    
}
include('../student/include/nav.php');
?>


<?php
include('../student/include/foot.php?hide_fab');
?>