<!--
README: This is the index.php file
Language: PHP

GO TO ./student/dashboard.php to edit the STUDENT DASHBOARD
CHECK OUT https://schoolnerd.manuthecoder.repl.co/
-->

<html>
  <head>
    <title>SchoolNerd</title>
    <!--Materialize CSS CDN -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/css/materialize.min.css">
    <style>
      nav a {color:gray !important}
    </style>
  </head>
  <body>
    <nav class="white">
      <ul>
        <li><a href="#" class="waves-effect">SchoolNerd</a></li>
      </ul>
      <ul class="right">
        <li><a href="https://schoolnerd.ml/student/login" class="waves-effect">Login</a></li>
      </ul>
    </nav>