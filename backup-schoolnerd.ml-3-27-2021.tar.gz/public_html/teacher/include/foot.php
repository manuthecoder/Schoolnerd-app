 <?php if($actual_link !== 'https://schoolnerd.ml/student/add_post.php?class='.$class) {?>
<div class="fixed-action-btn">
  <a class="btn-floating btn-large blue-grey darken-3 waves-effect waves-light" href="add_post.php?class=<?php echo $class; ?>">
    <i class="large material-icons">add</i>
  </a>
</div>
 <?php } ?>

 <!--<div style="width: 100%;background: rgba(0,0,0,0.1); padding: 10px;text-align:center">&copy;<?php echo date('Y'); ?> - SchoolNerd</div>-->
  <script src="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.0.0/dist/js/materialize.min.js"></script>
  </body>
</html>